package cf.esp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** All settings live in one key -> float map (booleans are 0/1, choices are indexes). */
final class Cfg {
    static final HashMap<String, Float> DEF = new HashMap<>();
    static final HashMap<String, Float> V = new HashMap<>();
    static final int[] ENEMY = {0xFFFF4A3D, 0xFFFF9F1A, 0xFFFF4FD8, 0xFF3DDCFF, 0xFFFFFFFF};
    static final int[] TEAM = {0xFF4ADE80, 0xFF5AB0FF, 0xFF3DDCFF, 0xFFFFE14D};
    static String pkg = "counterflame";

    private static void d(String k, float v) { DEF.put(k, v); }

    static {
        // players
        d("esp", 1); d("boxStyle", 1); d("chams", 1); d("glow", 1); d("headDot", 1);
        d("health", 1); d("hpText", 1); d("name", 1); d("dist", 1); d("snap", 0); d("offscreen", 1); d("teamCheck", 1);
        d("enemyCol", 0); d("teamCol", 0);
        // visuals
        d("radar", 1); d("radarRange", 40); d("crosshair", 0); d("maxDist", 150);
        d("lat", -20); d("fovScale", 1); d("fovH", 0); d("boxH", 1.8f); d("crouchH", 1.35f);
        // aim
        d("aim", 0); d("aimKey", 1); d("aimMode", 0); d("bone", 0); d("aimFov", 180); d("aimSmooth", 0.25f); d("ppd", 9); d("maxStep", 40); d("adv", 0); d("noRecoil", 0); d("noSpread", 0);
        d("trig", 0); d("trigPx", 28); d("trigMs", 30); d("fx", 0.92f); d("fy", 0.65f);
        d("bhop", 0); d("bhopSpeed", 9); d("fly", 0); d("flySpeed", 10); d("noclip", 0); d("mvSpeed", 1); d("mvJump", 1); d("mvGrav", 1); d("hud", 1);
        d("silent", 0); d("silentKey", 0); d("silentFov", 260); d("infAmmo", 0); d("wallbang", 0);
        d("invY", 0); d("sx", 0.62f); d("sy", 0.40f); d("lead", 60); d("showFov", 1);
        V.putAll(DEF);
    }

    static float f(String k) { Float v = V.get(k); return v == null ? 0f : v; }
    static boolean b(String k) { return f(k) >= 0.5f; }
    static int i(String k) { return Math.round(f(k)); }
    static void set(String k, float v) { V.put(k, v); }
    static int enemyColor() { return ENEMY[Math.max(0, Math.min(ENEMY.length - 1, i("enemyCol")))]; }
    static int teamColor() { return TEAM[Math.max(0, Math.min(TEAM.length - 1, i("teamCol")))]; }

    static void reset() { V.clear(); V.putAll(DEF); }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("wawer", Context.MODE_PRIVATE); }

    static void load(Context c) {
        SharedPreferences p = sp(c);
        for (Map.Entry<String, Float> e : DEF.entrySet()) V.put(e.getKey(), p.getFloat(e.getKey(), e.getValue()));
        pkg = p.getString("pkg", pkg);
    }

    static void save(Context c) {
        SharedPreferences.Editor ed = sp(c).edit();
        for (Map.Entry<String, Float> e : V.entrySet()) ed.putFloat(e.getKey(), e.getValue());
        ed.putString("pkg", pkg).apply();
    }

    /** config line for cf_core (see core_main.cpp) */
    static String coreLine(float W, float H, int rot) {
        return String.format(Locale.US,
                "C|aim=%d,key=%d,mode=%d,fov=%.1f,smooth=%.3f,ppd=%.2f,maxstep=%.1f,bone=%d,invy=%d,sx=%.3f,sy=%.3f,W=%.0f,H=%.0f,rot=%d,fs=%.3f,fh=%d,team=%d,maxd=%.0f,lead=%.0f,norecoil=%d,nospread=%d,bhop=%d,bhopspeed=%.1f,fly=%d,flyspeed=%.1f,noclip=%d,speed=%.2f,jump=%.2f,grav=%.2f,skey=%d,trig=%d,trigpx=%.0f,trigms=%.0f,fx=%.3f,fy=%.3f,silent=%d,silentfov=%.0f,infammo=%d,wallbang=%d\n",
                i("aim"), i("aimKey"), i("aimMode"), f("aimFov"), f("aimSmooth"), f("ppd"), f("maxStep"), i("bone"), i("invY"), f("sx"), f("sy"),
                W, H, rot, f("fovScale"), i("fovH"), i("teamCheck"), f("maxDist"), f("lead"), i("noRecoil"), i("noSpread"),
                i("bhop"), f("bhopSpeed"), i("fly"), f("flySpeed"), i("noclip"), f("mvSpeed"), f("mvJump"), f("mvGrav"), i("silentKey"), i("trig"), f("trigPx"), f("trigMs"), f("fx"), f("fy"),
                i("silent"), f("silentFov"), i("infAmmo"), i("wallbang"));
    }
}
