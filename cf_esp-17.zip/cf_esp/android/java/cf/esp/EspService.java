package cf.esp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EspService extends Service {
    private WindowManager wm;
    private EspView view;
    private TextView fab;                       // floating square button
    private WawerUi menu;
    private WindowManager.LayoutParams fabLp, menuLp;
    private Process proc;
    private OutputStream coreIn;
    private volatile boolean run;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable resend = new Runnable() {
        @Override public void run() { if (!run) return; sendCfg(); ui.postDelayed(this, 1500); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    public int onStartCommand(Intent in, int flags, int id) {
        if (view != null) return START_NOT_STICKY;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("cf", "Wawer", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "cf").setContentTitle("Wawer работает").setSmallIcon(android.R.drawable.ic_menu_view).build();
        startForeground(1, n);
        Cfg.load(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        view = new EspView(this);
        wm.addView(view, params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE));
        addFab();
        run = true;
        startCore();
        ui.postDelayed(resend, 1500);
        return START_NOT_STICKY;
    }

    private WindowManager.LayoutParams params(int w, int h, int extraFlags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                extraFlags | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        return lp;
    }

    private GradientDrawable rounded(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        g.setStroke(Math.max(1, dp(1)), stroke);
        return g;
    }

    /** square floating button: tap = open/close menu, drag = move */
    private void addFab() {
        fab = new TextView(this);
        fab.setText("W");
        fab.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        fab.setTypeface(Typeface.DEFAULT_BOLD);
        fab.setTextColor(WawerUi.ACCENT);
        fab.setGravity(Gravity.CENTER);
        fab.setBackground(rounded(0xCC101215, WawerUi.ACCENT, 11));
        fabLp = params(dp(42), dp(42), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        fabLp.x = dp(6); fabLp.y = dp(6);
        fab.setOnTouchListener(new android.view.View.OnTouchListener() {
            float dx, dy; int sx, sy; boolean moved;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: dx = e.getRawX(); dy = e.getRawY(); sx = fabLp.x; sy = fabLp.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > dp(6) || Math.abs(e.getRawY() - dy) > dp(6)) moved = true;
                        if (moved) { fabLp.x = sx + (int) (e.getRawX() - dx); fabLp.y = sy + (int) (e.getRawY() - dy); wm.updateViewLayout(fab, fabLp); }
                        return true;
                    case MotionEvent.ACTION_UP: if (!moved) toggleMenu(); return true;
                    default: return false;
                }
            }
        });
        wm.addView(fab, fabLp);
    }

    private void toggleMenu() {
        if (menu != null) { closeMenu(); return; }
        menu = new WawerUi(this, new WawerUi.Host() {
            @Override public void changed() { Cfg.save(EspService.this); sendCfg(); }
            @Override public void close() { closeMenu(); }
            @Override public void unload() { stopSelf(); }
        });
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int longSide = Math.max(dm.widthPixels, dm.heightPixels), shortSide = Math.min(dm.widthPixels, dm.heightPixels);
        int w = Math.min(dp(660), (int) (longSide * 0.66f)), hgt = Math.min(dp(430), (int) (shortSide * 0.88f));
        if (dm.widthPixels < dm.heightPixels) { w = (int) (dm.widthPixels * 0.96f); hgt = (int) (dm.heightPixels * 0.7f); }
        menuLp = params(w, hgt, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        menuLp.x = (dm.widthPixels - w) / 2;
        menuLp.y = (dm.heightPixels - hgt) / 2;
        menu.header.setOnTouchListener(new android.view.View.OnTouchListener() {   // drag the window by its header
            float dx, dy; int sx, sy;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: dx = e.getRawX(); dy = e.getRawY(); sx = menuLp.x; sy = menuLp.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        menuLp.x = sx + (int) (e.getRawX() - dx); menuLp.y = sy + (int) (e.getRawY() - dy);
                        if (menu != null) wm.updateViewLayout(menu.root, menuLp);
                        return true;
                    default: return true;
                }
            }
        });
        wm.addView(menu.root, menuLp);
    }

    private void closeMenu() {
        if (menu == null) return;
        try { wm.removeView(menu.root); } catch (Exception ignored) { }
        menu = null;
    }

    private void sendCfg() {
        final OutputStream os = coreIn;
        if (os == null || view == null) return;
        int w = view.getWidth(), h = view.getHeight();
        if (w <= 0 || h <= 0) return;
        final String line = Cfg.coreLine(w, h, wm.getDefaultDisplay().getRotation());
        io.execute(() -> { try { os.write(line.getBytes("UTF-8")); os.flush(); } catch (Exception ignored) { } });
    }

    private void startCore() {
        new Thread(() -> {
            try {
                File dst = new File(getFilesDir(), "cf_core");
                try (InputStream in = getAssets().open("cf_core"); FileOutputStream out = new FileOutputStream(dst)) {
                    byte[] buf = new byte[65536];
                    int k;
                    while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
                }
                dst.setReadable(true, false);
                String cmd = "cp '" + dst.getAbsolutePath() + "' /data/local/tmp/cf_core && chmod 755 /data/local/tmp/cf_core && exec /data/local/tmp/cf_core -p " + Cfg.pkg;
                proc = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
                coreIn = proc.getOutputStream();
                ui.post(this::sendCfg);
                BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                while (run && (line = br.readLine()) != null) Model.publish(Model.parse(line));
                if (run) Model.publish(Model.status("core exited (нет root?)"));
            } catch (Exception e) {
                Model.publish(Model.status("core error: " + e));
            }
        }, "cf-core").start();
    }

    @Override
    public void onDestroy() {
        run = false;
        ui.removeCallbacksAndMessages(null);
        try { if (coreIn != null) coreIn.close(); } catch (Exception ignored) { }
        if (proc != null) proc.destroy();
        new Thread(() -> { try { Runtime.getRuntime().exec(new String[]{"su", "-c", "pkill -f cf_core"}).waitFor(); } catch (Exception ignored) { } }).start();
        closeMenu();
        try { if (view != null) wm.removeView(view); } catch (Exception ignored) { }
        try { if (fab != null) wm.removeView(fab); } catch (Exception ignored) { }
        view = null; fab = null;
        io.shutdown();
        super.onDestroy();
    }
}
