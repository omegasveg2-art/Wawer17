// il2cpp structure helpers. Layout constants are Il2CppClass from il2cpp.h of the dump (64-bit, Unity 2021.2+).
#pragma once
#include "mem.h"
#include "offsets.h"
#include <functional>
#include <map>

namespace il2 {
constexpr uint32_t K_NAME = 0x10, K_NS = 0x18, K_SELF = 0x78, K_STATICS = 0xB8;   // Il2CppClass
constexpr uint32_t K_METHODS = 0x98, K_MCOUNT = 0x11C;                            // Il2CppClass.methods / method_count
constexpr uint32_t MI_PTR = 0x0, MI_NAME = 0x18, MI_NPARAMS = 0x52;               // MethodInfo
constexpr uint32_t LIST_ITEMS = 0x10, LIST_SIZE = 0x18;                           // List<T>
constexpr uint32_t ARR_LEN = 0x18, ARR_DATA = 0x20;                               // T[]
constexpr uint32_t STR_LEN = 0x10, STR_CHARS = 0x14;                              // System.String
}

class Il2 {
public:
    Il2(IMem& m, uint64_t base) : m_(m), base_(base) {}
    // Il2CppClass* for a class: TypeInfo slot from the dump first, then name scan if the slot is empty/stale.
    uint64_t klass(const ClassRef& c);
    // native entry point of method `name` (nparams < 0: any) from Il2CppClass.methods -- no RVA needed, survives game updates
    uint64_t method_addr(uint64_t klass, const char* name, int nparams = -1);
    uint64_t statics(uint64_t k) { return k ? rdp(m_, k + il2::K_STATICS) : 0; }
    std::string cstr(uint64_t a, size_t max = 96);
    std::string str(uint64_t s, size_t maxchars = 31);      // System.String -> ascii ('?' for non-ascii)
    // all 8-aligned addresses in rw anon memory holding `klass` as first word and passing `accept`
    std::vector<uint64_t> find_instances(uint64_t klass, const std::function<bool(uint64_t)>& accept);
    bool klass_ok(uint64_t k, const ClassRef& c);
    void set_scan_gap(double s) { gap_ = s; nextScan_ = 0; }
    int classes_seen() const { return seen_; }          // diagnostics: Il2CppClass structs found by the last full scan
    // List<T> -> (items ptr, size); false if implausible
    bool list(uint64_t l, uint64_t& items, uint32_t& size, uint32_t maxsize = 4096);
private:
    uint64_t scan_klass(const ClassRef& c);
    void scan_all();
    std::map<std::string, uint64_t> byName_;             // ns + '\\0' + name -> Il2CppClass*
    double nextScan_ = 0, gap_ = 8.0;
    int seen_ = 0;
    IMem& m_;
    uint64_t base_;
};
